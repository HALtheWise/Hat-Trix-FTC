#define BALLE

#define BackL FrontL
#define BackR FrontR

#define car auxMotor
#define elevator auxMotor
#define servo motor
#define grabberServo auxMotor

#define SCALAR 1677.6 //Wheel circumference known to be 21.6cm
//happy
