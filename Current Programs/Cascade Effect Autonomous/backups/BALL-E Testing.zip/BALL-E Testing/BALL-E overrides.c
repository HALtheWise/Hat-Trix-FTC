#define BackL FrontL
#define BackR FrontR

#define car auxMotor
#define elevator auxMotor
#define grabberServo auxMotor
#define servo motor

#define BALLE

#define SCALAR 1677.6 //Wheel circumference known to be 21.6cm
//happy
